﻿namespace NPL.M.A008.Exercise2.Models
{
    public class Ford : Car
    {
        public Ford()
        {

        }
        public Ford(decimal speed, double regularPrice, string color, int year, int manufacturerDiscount)
            : base(speed, regularPrice, color)
        {
            ManufacturerDiscount = manufacturerDiscount;
        }

        public int Year { get; set; }

        public int ManufacturerDiscount { get; set; }

        public override string ToString()
        {
            return base.ToString() + "   " + string.Format("{0, -10}{1, 20}", Year, ManufacturerDiscount);
        }

        public override double GetSalePrice()
        {
            return RegularPrice * ManufacturerDiscount;
        }

    }
}
