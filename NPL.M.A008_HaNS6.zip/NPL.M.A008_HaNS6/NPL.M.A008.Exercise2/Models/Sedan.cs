﻿namespace NPL.M.A008.Exercise2.Models
{
    public class Sedan : Car
    {
        public Sedan()
        {

        }
        public Sedan(decimal speed, double regularPrice, string color, int length)
            : base(speed, regularPrice, color)
        {
            Length = length;
        }

        public int Length { get; set; }

        public override string ToString()
        {
            return base.ToString() + "   " + string.Format("{0, -20}", Length);
        }

        public override double GetSalePrice()
        {
            if (Length > 20)
            {
                return RegularPrice * 0.05;
            }
            else
            {
                return RegularPrice * 0.1;
            }
        }
    }
}
