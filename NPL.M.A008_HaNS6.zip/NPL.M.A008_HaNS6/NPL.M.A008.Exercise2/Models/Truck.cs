﻿namespace NPL.M.A008.Exercise2.Models
{
    public class Truck : Car
    {
        public Truck()
        {

        }
        public Truck(decimal speed, double regularPrice, string color, int weight)
            : base(speed, regularPrice, color)
        {
            Weight = weight;
        }

        public int Weight { get; set; }

        public override string ToString()
        {
            return base.ToString() + "   " + string.Format("{0, -20}", Weight);
        }

        public override double GetSalePrice()
        {
            if (Weight > 2000)
            {
                return 0.1 * RegularPrice;
            }
            else
            {
                return 0.2 * RegularPrice;
            }
        }
    }
}
