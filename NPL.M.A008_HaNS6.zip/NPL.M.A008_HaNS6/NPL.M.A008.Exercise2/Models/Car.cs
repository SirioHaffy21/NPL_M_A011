﻿namespace NPL.M.A008.Exercise2.Models
{
    public class Car
    {
        public Car()
        {

        }
        public Car(decimal speed, double regularPrice, string color)
        {
            Speed = speed;
            RegularPrice = regularPrice;
            Color = color;
        }

        public decimal Speed { get; set; }

        public double RegularPrice { get; set; }

        public string Color { get; set; }

        public virtual double GetSalePrice()
        {
            return RegularPrice;
        }

        public override string ToString()
        {
            return string.Format("{0, -20}{1, 20}{2, 20}", Speed, RegularPrice, Color);
        }
    }
}
