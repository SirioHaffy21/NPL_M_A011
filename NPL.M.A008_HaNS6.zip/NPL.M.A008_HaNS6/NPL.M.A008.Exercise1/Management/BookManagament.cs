﻿using NPL.M.A008.Models;
using System;
using System.Collections.Generic;

namespace NPL.M.A008.Management
{
    public class BookManagament
    {
        public static List<Book> listBooks { get; set; } = new List<Book>();

        public void Add(Book book)
        {
            listBooks.Add(book);
        }

        public void DisplayAll()
        {
            foreach (var item in listBooks)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}
