﻿using NPL.M.A008.Management;
using NPL.M.A008.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NPL.M.A008.Exercise1
{
    internal class Program
    {
        public static BookManagament bookManagament = new BookManagament();
        private static void Main(string[] args)
        {
            MainMenu();
        }

        private static void MainMenu()
        {
            int selectFearture = 0;

            do
            {
                Console.WriteLine("Select feature");
                Console.WriteLine("1. Input book. ");
                Console.WriteLine("2. Display all book. ");
                Console.WriteLine("3. Exit. ");
                Console.Write("Enter feature: ");
                while (true)
                {
                    if (int.TryParse(Console.ReadLine(), out selectFearture))
                    {
                        break;
                    }
                }

                switch (selectFearture)
                {
                    case 1:
                        InputtingBook();

                        break;
                    case 2:
                        GetBookInformation();
                        break;
                    case 3:
                        Environment.Exit(0);
                        break;
                }
            } while (selectFearture != 3 || selectFearture != 2 || selectFearture != 1);
        }

        private static void GetBookInformation()
        {
            bookManagament.DisplayAll();
        }

        private static void InputtingBook()
        {
            Console.Write("Input name of book: ");
            string bookName = string.Empty;
            bookName = Console.ReadLine();

            Console.Write("Input isbn of book: ");
            string iSBN = string.Empty;
            iSBN = Console.ReadLine();

            Console.Write("Input author of book: ");
            string authorName = string.Empty;
            authorName = Console.ReadLine();

            Console.Write("Input publisher of book: ");
            string publisherName = string.Empty;
            publisherName = Console.ReadLine();

            Book bookItem = new Book(bookName, iSBN, authorName, publisherName);
            bookManagament.Add(bookItem);
        }

      
    }
}
