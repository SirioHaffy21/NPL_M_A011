﻿using NPL.M.A008.Exercise2.Models;
using System;
using System.Collections.Generic;

namespace NPL.M.A008.Exercise2
{
    internal class MyOwnAutoShop
    {
        private static void Main(string[] args)
        {
            List<Truck> listTrucks = new List<Truck>();
            List<Ford> listFords = new List<Ford>();
            List<Sedan> listSedans = new List<Sedan>();

            InputCars(listTrucks, listFords, listSedans);

            Console.WriteLine("==========================");

            OutputCars(listTrucks, listFords, listSedans);

            Console.ReadKey();
        }

        /// <summary>
        /// Input cars
        /// </summary>
        /// <param name="listTrucks"></param>
        /// <param name="listFords"></param>
        /// <param name="listSedans"></param>
        private static void InputCars(List<Truck> listTrucks, List<Ford> listFords, List<Sedan> listSedans)
        {
            Sedan sedan = new Sedan(2, 5.22, "Red", 30);
            listSedans.Add(sedan);

            Truck truck1 = new Truck(3, 2.55, "Blue", 3000);
            Truck truck2 = new Truck(2, 2.25, "Yellow", 1500);
            listTrucks.Add(truck1);
            listTrucks.Add(truck2);

            Ford ford1 = new Ford(3, 3.22, "Green", 200, 50);
            Ford ford2 = new Ford(4, 4.12, "Orange", 250, 30);
            listFords.Add(ford1);
            listFords.Add(ford2);
        }

        /// <summary>
        /// Output cars
        /// </summary>
        /// <param name="listTrucks"></param>
        /// <param name="listFords"></param>
        /// <param name="listSedans"></param>
        private static void OutputCars(List<Truck> listTrucks, List<Ford> listFords, List<Sedan> listSedans)
        {
            Console.WriteLine("All Sedan: ");
            foreach (var itemsSedan in listSedans)
            {
                Console.WriteLine("\t " + itemsSedan.ToString() + "  " + itemsSedan.GetSalePrice());
            }
            Console.WriteLine("");

            Console.WriteLine("All Ford: ");
            foreach (var itemsFord in listFords)
            {
                Console.WriteLine("\t " + itemsFord.ToString() + "  " + itemsFord.GetSalePrice());
            }
            Console.WriteLine("");

            Console.WriteLine("All Truck");
            foreach (var itemTrucks in listTrucks)
            {
                Console.WriteLine("\t " + itemTrucks.ToString() + "  " + itemTrucks.GetSalePrice());
            }
        }

        
    }
}
