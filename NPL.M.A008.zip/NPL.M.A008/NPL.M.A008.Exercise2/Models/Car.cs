﻿namespace NPL.M.A008.Exercise2.Models
{
    public class Car
    {
        public decimal Speed { get; set; }
        public double RegularPrice { get; set; }
        public string Color { get; set; }
    }
}
