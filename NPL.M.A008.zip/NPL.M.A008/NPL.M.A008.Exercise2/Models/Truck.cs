﻿namespace NPL.M.A008.Exercise2.Models
{
    public class Truck : Car
    {
        public Truck()
        {

        }
        public Truck(decimal speed, double regularPrice, string color, int weight)
        {
            Speed = speed;
            RegularPrice = regularPrice;
            Color = color;
            Weight = weight;
        }

        public int Weight { get; set; }

        public override string ToString()
        {
            return Speed + " | " + RegularPrice + " | " + Color + " | " + Weight + " | ";
        }

        public double GetSalePrice() {
            if (Weight > 2000)
            {
                return 0.1 * RegularPrice;
            }
            else
            {
                return 0.2 * RegularPrice;
            }
        }
    }
}
