﻿namespace NPL.M.A008.Exercise2.Models
{
    public class Ford : Car
    {
        public Ford()
        {

        }
        public Ford(decimal speed, double regularPrice, string color, int year, int manufacturerDiscount)
        {
            Speed = speed;
            RegularPrice = regularPrice;
            Color = color;
            Year = year;
            ManufacturerDiscount = manufacturerDiscount;
        }

        public int Year { get; set; }

        public int ManufacturerDiscount { get; set; }

        public override string ToString()
        {
            return Speed + " | " + RegularPrice + " | " + Color + " | " + Year + " | " + ManufacturerDiscount + " | ";
        }

        public double GetSalePrice()
        {
            return RegularPrice * ManufacturerDiscount;
        }

    }
}
