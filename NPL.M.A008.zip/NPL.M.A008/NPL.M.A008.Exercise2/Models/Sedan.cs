﻿namespace NPL.M.A008.Exercise2.Models
{
    public class Sedan : Car
    {
        public Sedan()
        {

        }
        public Sedan(decimal speed, double regularPrice, string color, int length)
        {
            Speed = speed;
            RegularPrice = regularPrice;
            Color = color;
            Length = length;
        }

        public int Length { get; set; }

        public override string ToString()
        {
            return Speed + " | " + RegularPrice + " | " + Color + " | " + Length + " | ";
        }

        public double GetSalePrice()
        {
            if (Length > 20)
            {
                return RegularPrice * 0.05;
            }
            else
            {
                return RegularPrice * 0.1;
            }
        }
    }
}
