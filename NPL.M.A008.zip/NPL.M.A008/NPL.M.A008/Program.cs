﻿using NPL.M.A008.Models;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace NPL.M.A008.Exercise1
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            List<Book> listBooks = new List<Book>();
            int selectFearture = 0;
            while(selectFearture != 3)
            {
                Console.WriteLine("Select feature");
                Console.WriteLine("1. Input book. ");
                Console.WriteLine("2. Display all book. ");
                Console.WriteLine("3. Exit. ");
                Console.Write("Enter feature: ");
                while (true)
                {
                    if (int.TryParse(Console.ReadLine(), out selectFearture))
                    {
                        break;
                    }
                }

                switch (selectFearture)
                {
                    case 1:
                        InputtingBook(listBooks);

                        break;
                    case 2:
                        GetBookInformation(listBooks);
                        break;
                    case 3:
                        break;
                }

                
            }
        }
        
        /// <summary>
        /// Inputting book
        /// </summary>
        /// <param name="listBooks"></param>
        private static void InputtingBook(List<Book> listBooks)
        {
            Console.Write("Input a book name: ");
            string bookName = Console.ReadLine();

            string bookISBN = string.Empty;
            while (CheckISBN(bookISBN) != true)
            {
                Console.Write("Input a ISBN name: ");
                bookISBN = Console.ReadLine();
            }

            Console.Write("Input a author name: ");
            string authorName = Console.ReadLine();

            Console.Write("Input a publisher name: ");
            string publisherName = Console.ReadLine();

            Book book = new Book(bookISBN, bookName, authorName, publisherName);
            listBooks.Add(book);
        }

        /// <summary>
        /// Get information of book
        /// </summary>
        /// <param name="listBooks"></param>
        private static void GetBookInformation(List<Book> listBooks)
        {
            Console.WriteLine("Information display: ");
            Console.WriteLine("");

            foreach (var item in listBooks)
            {
                Console.WriteLine("\t" + item.ToString());
            }
        }

        /// <summary>
        /// check ISBN of Book
        /// </summary>
        /// <param name="bookISBN"></param>
        /// <returns></returns>
        private static bool CheckISBN(string bookISBN)
        {
            string pattern = @"[0-9]{8,}";

            Regex regex = new Regex(pattern);

            Match match = regex.Match(bookISBN);

            if (match.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
