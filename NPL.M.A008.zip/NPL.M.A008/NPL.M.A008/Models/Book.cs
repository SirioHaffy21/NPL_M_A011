﻿namespace NPL.M.A008.Models
{
    public class Book
    {
        public Book()
        {

        }

        public Book(string bookName, string iSBN, string authorName, string publisherName)
        {
            BookName = bookName;
            ISBN = iSBN;
            AuthorName = authorName;
            PublisherName = publisherName;
        }

        public string BookName { get; set; }
        public string ISBN { get; set; }
        public string AuthorName { get; set; }
        public string PublisherName { get; set; }

        public override string ToString()
        {
            return ISBN + "      " + BookName + "      " + AuthorName + "      " + PublisherName;
        }
       
    
    }
}
